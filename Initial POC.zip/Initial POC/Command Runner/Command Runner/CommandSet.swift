//
//  CommandSet.swift
//  Command Runner
//
//  Created by Jordan Trbuhovic on 11/08/23.
//  Copyright © 2023 Jordan Trbuhovic. All rights reserved.
//

import Foundation

struct CommandSet: Codable {
    var name: String
    var commands: [String]
}
