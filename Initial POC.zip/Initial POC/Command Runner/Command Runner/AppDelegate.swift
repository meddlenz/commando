//
//  AppDelegate.swift
//  Command Runner
//
//  Created by Jordan Trbuhovic on 10/08/23.
//  Copyright © 2023 Jordan Trbuhovic. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {
    var statusBarItem: NSStatusItem!
    var menu: NSMenu!

    func applicationDidFinishLaunching(_ aNotification: Notification) {
        statusBarItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)

        if let button = statusBarItem.button {
            button.image = NSImage(named: "MenuBarIcon")
            button.action = #selector(statusBarButtonClicked(sender:))
        }
        
        menu = NSMenu()
        menu.addItem(NSMenuItem(title: "Settings", action: #selector(openSettings), keyEquivalent: ""))
        menu.addItem(NSMenuItem.separator())
        menu.addItem(NSMenuItem(title: "Quit", action: #selector(NSApplication.terminate(_:)), keyEquivalent: ""))
        NotificationCenter.default.addObserver(self, selector: #selector(updateMenuWithCommandSets), name: .commandSetSaved, object: nil)
    }
    
    @objc func statusBarButtonClicked(sender: NSStatusBarButton) {
        updateMenuWithCommandSets()
        statusBarItem.menu = menu
        statusBarItem.button?.performClick(nil) // This opens the menu
    }

    @objc func updateMenuWithCommandSets() {
        // Clear existing command set menu items
        while menu.items.count > 3 {
            menu.removeItem(at: 0)
        }
        
        // Retrieve command sets from UserDefaults
        let commandSets = SettingsWindowController().getCommandSetsFromDefaults()
        
        // Create menu items for each command set
        for commandSet in commandSets.reversed() {
            let menuItem = NSMenuItem(title: commandSet.name, action: #selector(runSelectedCommandSet(sender:)), keyEquivalent: "")
            menuItem.target = self
            menuItem.representedObject = commandSet
            menu.insertItem(menuItem, at: 0)
        }
    }
    
    

    func runCommandSet(_ commandSet: CommandSet) {
        for command in commandSet.commands {
            // Run the shell command
            _ = try? shell(command)
        }
    }

    @objc func openSettings() {
        let settingsWindowController = SettingsWindowController()
        settingsWindowController.showWindow(self)
    }
    
    @objc func runSelectedCommandSet(sender: NSMenuItem) {
        if let commandSet = sender.representedObject as? CommandSet {
            for command in commandSet.commands {
                // Run the shell command
                _ = try? shell(command)
            }
        }
    }

    func shell(_ command: String) throws -> String {
        let process = Process()
        process.launchPath = "/bin/bash"
        process.arguments = ["-c", command]

        let outputPipe = Pipe()
        process.standardOutput = outputPipe
        process.launch()

        let outputData = outputPipe.fileHandleForReading.readDataToEndOfFile()
        let output = String(data: outputData, encoding: .utf8)

        return output ?? ""
    }
    
    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }

    
    
}

extension Notification.Name {
    static let commandSetSaved = Notification.Name("commandSetSaved")
}


