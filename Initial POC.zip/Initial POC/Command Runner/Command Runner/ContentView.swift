//
//  ContentView.swift
//  Command Runner
//
//  Created by Jordan Trbuhovic on 10/08/23.
//  Copyright © 2023 Jordan Trbuhovic. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, World!")
            .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
