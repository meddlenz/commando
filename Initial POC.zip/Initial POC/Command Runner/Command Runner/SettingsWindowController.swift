//
//  SettingsWindowController.swift
//  Command Runner
//
//  Created by Jordan Trbuhovic on 10/08/23.
//  Copyright © 2023 Jordan Trbuhovic. All rights reserved.
//

import Cocoa


class SettingsWindowController: NSWindowController, NSWindowDelegate {
    @IBOutlet weak var commandSetNameTextField: NSTextField!
    @IBOutlet weak var commandsTextView: NSScrollView!

    override var windowNibName: NSNib.Name? {
        return NSNib.Name("SettingsWindowController")
    }

    // Define this method to save a command set
  @IBAction func saveCommandSet(_ sender: Any) {
      print("Save button was clicked") // Log that the button was clicked

      let name = commandSetNameTextField.stringValue
      if let textView = commandsTextView.documentView as? NSTextView {
          let commands = textView.string.split(separator: "\n").map(String.init)
          print("Commands: \(commands)") // Log the commands
          let commandSet = CommandSet(name: name, commands: commands)
          saveCommandSetToDefaults(commandSet)

          // Close the settings window
          self.close()
          NotificationCenter.default.post(name: .commandSetSaved, object: nil)
      } else {
          print("Unable to cast documentView to NSTextView") // Log failure to cast
      }
  }
    
    @IBAction func testButtonClick(_ sender: Any) {
        print("Button was clicked!")
    }


    // Add this method to save a command set to UserDefaults
   func saveCommandSetToDefaults(_ commandSet: CommandSet) {
        print("Saving command set to defaults") // Log saving attempt
        let defaults = UserDefaults.standard
        var commandSets = getCommandSetsFromDefaults()

        commandSets.append(commandSet)

        if let data = try? JSONEncoder().encode(commandSets) {
            defaults.set(data, forKey: "commandSets")
        } else {
            print("Failed to encode command sets") // Log failure to encode
        }
    }


    // Add this method to retrieve command sets from UserDefaults
    func getCommandSetsFromDefaults() -> [CommandSet] {
        let defaults = UserDefaults.standard

        if let data = defaults.data(forKey: "commandSets"),
           let commandSets = try? JSONDecoder().decode([CommandSet].self, from: data) {
            return commandSets
        } else {
            return []
        }
    }

}
