import Cocoa

@main
class AppDelegate: NSObject, NSApplicationDelegate {

    private var statusItem: NSStatusItem!
    private var configureWindowController: ConfigureWindowController?

    func applicationDidFinishLaunching(_ notification: Notification) {
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)

        if let button = statusItem.button {
            button.title = "Cmd"
            button.toolTip = "Command Runner"
        }

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(serverCommandsDidChange(_:)),
            name: .serverCommandsDidChange,
            object: nil
        )

        constructMenu()
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        false
    }

    func applicationWillTerminate(_ notification: Notification) {
    }

    @objc private func serverCommandsDidChange(_ notification: Notification) {
        constructMenu()
    }

    func constructMenu() {
        let menu = NSMenu()
        let commands = UserDefaults.standard.serverCommands

        if commands.isEmpty {
            let emptyItem = NSMenuItem(title: "No commands configured", action: nil, keyEquivalent: "")
            emptyItem.isEnabled = false
            menu.addItem(emptyItem)
        } else {
            for (index, command) in commands.enumerated() {
                let title = command.name.isEmpty ? command.serverDetails : command.name
                let item = NSMenuItem(
                    title: title,
                    action: #selector(runConfiguredCommand(_:)),
                    keyEquivalent: ""
                )
                item.tag = index
                item.target = self
                menu.addItem(item)
            }
        }

        menu.addItem(NSMenuItem.separator())
        menu.addItem(NSMenuItem(
            title: "Configure...",
            action: #selector(openConfigureWindow(_:)),
            keyEquivalent: ","
        ))
        menu.addItem(NSMenuItem.separator())
        menu.addItem(NSMenuItem(
            title: "Quit",
            action: #selector(NSApplication.terminate(_:)),
            keyEquivalent: "q"
        ))

        statusItem.menu = menu
    }

    @objc func runConfiguredCommand(_ sender: NSMenuItem) {
        let commands = UserDefaults.standard.serverCommands
        guard commands.indices.contains(sender.tag) else {
            constructMenu()
            return
        }

        let command = commands[sender.tag]

        do {
            try CommandExecutor.run(command)
        } catch {
            presentError(error)
        }
    }

    @objc func openConfigureWindow(_ sender: Any?) {
        if configureWindowController == nil {
            configureWindowController = ConfigureWindowController()
        }
        configureWindowController?.showWindow(nil)
        NSApp.activate(ignoringOtherApps: true)
    }

    private func presentError(_ error: Error) {
        let alert = NSAlert()
        alert.messageText = "Unable to run command"
        alert.informativeText = error.localizedDescription
        alert.alertStyle = .warning
        alert.addButton(withTitle: "OK")
        alert.runModal()
    }
}
