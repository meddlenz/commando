//
//  ConfigureWindowController.swift
//  Command Runner
//

import Cocoa

class ConfigureWindowController: NSWindowController {

    private var commands: [ServerCommand] = []
    private var selectedIndex: Int?
    private var isUpdatingDetailFields = false

    private let tableView = NSTableView()
    private let nameField = NSTextField()
    private let serverField = NSTextField()
    private let stepsTextView = NSTextView()
    private let detailLabel = NSTextField(labelWithString: "Select a command to edit its details.")

    init() {
        let window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 620, height: 560),
            styleMask: [.titled, .closable, .miniaturizable, .resizable],
            backing: .buffered,
            defer: false
        )
        window.title = "Configure Commands"
        window.minSize = NSSize(width: 520, height: 420)
        window.center()
        super.init(window: window)
        buildInterface()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func showWindow(_ sender: Any?) {
        commands = UserDefaults.standard.serverCommands
        reloadTable(selecting: commands.isEmpty ? nil : min(selectedIndex ?? 0, commands.count - 1))
        super.showWindow(sender)
    }

    private func buildInterface() {
        guard let contentView = window?.contentView else { return }

        let commandsLabel = sectionLabel("Saved Commands")
        let addButton = NSButton(title: "Add", target: self, action: #selector(addServerCommand(_:)))
        let removeButton = NSButton(title: "Remove", target: self, action: #selector(removeServerCommand(_:)))

        configureTableView()

        let tableScrollView = NSScrollView()
        tableScrollView.hasVerticalScroller = true
        tableScrollView.borderType = .bezelBorder
        tableScrollView.documentView = tableView

        let buttonRow = NSStackView(views: [addButton, removeButton])
        buttonRow.orientation = .horizontal
        buttonRow.spacing = 8

        let commandsSection = NSStackView(views: [commandsLabel, tableScrollView, buttonRow])
        commandsSection.orientation = .vertical
        commandsSection.alignment = .width
        commandsSection.spacing = 8
        commandsSection.translatesAutoresizingMaskIntoConstraints = false

        let detailBox = NSBox()
        detailBox.title = "Command Details"
        detailBox.translatesAutoresizingMaskIntoConstraints = false

        let detailContent = buildDetailContent()
        detailContent.translatesAutoresizingMaskIntoConstraints = false
        detailBox.addSubview(detailContent)

        contentView.addSubview(commandsSection)
        contentView.addSubview(detailBox)

        NSLayoutConstraint.activate([
            commandsSection.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 20),
            commandsSection.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            commandsSection.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),

            tableScrollView.heightAnchor.constraint(greaterThanOrEqualToConstant: 140),

            detailBox.topAnchor.constraint(equalTo: commandsSection.bottomAnchor, constant: 16),
            detailBox.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            detailBox.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            detailBox.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -20),

            detailContent.leadingAnchor.constraint(equalTo: detailBox.leadingAnchor, constant: 16),
            detailContent.trailingAnchor.constraint(equalTo: detailBox.trailingAnchor, constant: -16),
            detailContent.topAnchor.constraint(equalTo: detailBox.topAnchor, constant: 20),
            detailContent.bottomAnchor.constraint(equalTo: detailBox.bottomAnchor, constant: -12),
        ])
    }

    private func buildDetailContent() -> NSView {
        detailLabel.font = NSFont.systemFont(ofSize: NSFont.smallSystemFontSize)
        detailLabel.textColor = .secondaryLabelColor

        nameField.placeholderString = "Display name"
        nameField.target = self
        nameField.action = #selector(detailFieldChanged(_:))

        serverField.placeholderString = "username@host or username@host:22"
        serverField.target = self
        serverField.action = #selector(detailFieldChanged(_:))

        let stepsLabel = NSTextField(labelWithString: "Steps (one per line, run in order):")

        let stepsScrollView = NSScrollView()
        stepsScrollView.hasVerticalScroller = true
        stepsScrollView.borderType = .bezelBorder
        stepsTextView.isRichText = false
        stepsTextView.font = NSFont.monospacedSystemFont(ofSize: NSFont.systemFontSize, weight: .regular)
        stepsTextView.isEditable = true
        stepsTextView.delegate = self
        stepsTextView.minSize = NSSize(width: 0, height: 80)
        stepsScrollView.documentView = stepsTextView

        let stack = NSStackView()
        stack.orientation = .vertical
        stack.alignment = .width
        stack.spacing = 8
        stack.addArrangedSubview(detailLabel)
        stack.addArrangedSubview(formRow(label: "Name", control: nameField))
        stack.addArrangedSubview(formRow(label: "Server", control: serverField))
        stack.addArrangedSubview(stepsLabel)
        stack.addArrangedSubview(stepsScrollView)

        stack.setCustomSpacing(12, after: detailLabel)
        stepsScrollView.translatesAutoresizingMaskIntoConstraints = false
        stepsScrollView.heightAnchor.constraint(equalToConstant: 100).isActive = true

        return stack
    }

    private func sectionLabel(_ title: String) -> NSTextField {
        let label = NSTextField(labelWithString: title)
        label.font = NSFont.boldSystemFont(ofSize: NSFont.systemFontSize)
        return label
    }

    private func formRow(label: String, control: NSControl) -> NSView {
        let labelField = NSTextField(labelWithString: label)
        labelField.setContentHuggingPriority(.defaultHigh, for: .horizontal)
        labelField.setContentCompressionResistancePriority(.required, for: .horizontal)

        control.setContentHuggingPriority(.defaultLow, for: .horizontal)

        let row = NSStackView(views: [labelField, control])
        row.orientation = .horizontal
        row.spacing = 8
        row.alignment = .centerY
        row.distribution = .fill
        row.translatesAutoresizingMaskIntoConstraints = false
        return row
    }

    private func configureTableView() {
        tableView.dataSource = self
        tableView.delegate = self
        tableView.target = self
        tableView.doubleAction = #selector(focusDetailEditor(_:))
        tableView.usesAlternatingRowBackgroundColors = true
        tableView.columnAutoresizingStyle = .uniformColumnAutoresizingStyle

        let columns: [(String, String, CGFloat)] = [
            ("name", "Name", 140),
            ("server", "Server", 180),
            ("steps", "Steps", 220),
        ]

        for (identifier, title, width) in columns {
            let column = NSTableColumn(identifier: NSUserInterfaceItemIdentifier(identifier))
            column.title = title
            column.width = width
            tableView.addTableColumn(column)
        }
    }

    @objc private func focusDetailEditor(_ sender: Any?) {
        window?.makeFirstResponder(stepsTextView)
    }

    @objc private func detailFieldChanged(_ sender: Any?) {
        commitDetailFieldsToSelection()
    }

    private func commitDetailFieldsToSelection() {
        guard !isUpdatingDetailFields,
              let index = selectedIndex,
              commands.indices.contains(index) else { return }

        commands[index].name = nameField.stringValue
        commands[index].serverDetails = serverField.stringValue
        commands[index].steps = stepsFromEditorText(stepsTextView.string)

        UserDefaults.standard.serverCommands = commands
        tableView.reloadData(forRowIndexes: IndexSet(integer: index), columnIndexes: IndexSet(integersIn: 0..<tableView.numberOfColumns))
    }

    private func stepsFromEditorText(_ text: String) -> [String] {
        let lines = text.components(separatedBy: .newlines)
        return lines.isEmpty ? [""] : lines
    }

    private func editorText(from steps: [String]) -> String {
        steps.joined(separator: "\n")
    }

    private func reloadTable(selecting index: Int?) {
        tableView.reloadData()

        if let index, commands.indices.contains(index) {
            selectedIndex = index
            tableView.selectRowIndexes(IndexSet(integer: index), byExtendingSelection: false)
        } else {
            selectedIndex = nil
            tableView.deselectAll(nil)
        }

        updateDetailFields()
    }

    private func updateDetailFields() {
        isUpdatingDetailFields = true
        defer { isUpdatingDetailFields = false }

        guard let index = selectedIndex, commands.indices.contains(index) else {
            nameField.stringValue = ""
            serverField.stringValue = ""
            stepsTextView.string = ""
            nameField.isEnabled = false
            serverField.isEnabled = false
            stepsTextView.isEditable = false
            detailLabel.stringValue = commands.isEmpty
                ? "Add a command to get started."
                : "Select a command to edit its details."
            return
        }

        let command = commands[index]
        nameField.stringValue = command.name
        serverField.stringValue = command.serverDetails
        stepsTextView.string = editorText(from: command.steps)
        nameField.isEnabled = true
        serverField.isEnabled = true
        stepsTextView.isEditable = true
        detailLabel.stringValue = "Editing \"\(command.name)\""
    }

    @IBAction func addServerCommand(_ sender: Any) {
        let newCommand = ServerCommand()
        commands.append(newCommand)
        UserDefaults.standard.serverCommands = commands
        reloadTable(selecting: commands.count - 1)
        window?.makeFirstResponder(nameField)
    }

    @IBAction func removeServerCommand(_ sender: Any) {
        let selectedRow = tableView.selectedRow
        guard selectedRow >= 0, commands.indices.contains(selectedRow) else { return }

        commands.remove(at: selectedRow)

        let nextSelection: Int?
        if commands.isEmpty {
            nextSelection = nil
        } else {
            nextSelection = min(selectedRow, commands.count - 1)
        }

        UserDefaults.standard.serverCommands = commands
        reloadTable(selecting: nextSelection)
    }
}

extension ConfigureWindowController: NSTableViewDataSource, NSTableViewDelegate {

    func numberOfRows(in tableView: NSTableView) -> Int {
        commands.count
    }

    func tableView(_ tableView: NSTableView, viewFor tableColumn: NSTableColumn?, row: Int) -> NSView? {
        guard commands.indices.contains(row), let column = tableColumn else { return nil }

        let command = commands[row]
        let identifier = column.identifier.rawValue

        let cell = (tableView.makeView(withIdentifier: column.identifier, owner: self) as? NSTableCellView)
            ?? makeCell(for: column)

        switch identifier {
        case "name":
            cell.textField?.stringValue = command.name
        case "server":
            cell.textField?.stringValue = command.serverDetails
        case "steps":
            cell.textField?.stringValue = command.stepsSummary
        default:
            cell.textField?.stringValue = ""
        }

        return cell
    }

    private func makeCell(for column: NSTableColumn) -> NSTableCellView {
        let cell = NSTableCellView()
        cell.identifier = column.identifier

        let textField = NSTextField(labelWithString: "")
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.lineBreakMode = .byTruncatingTail
        cell.addSubview(textField)
        cell.textField = textField

        NSLayoutConstraint.activate([
            textField.leadingAnchor.constraint(equalTo: cell.leadingAnchor, constant: 4),
            textField.trailingAnchor.constraint(equalTo: cell.trailingAnchor, constant: -4),
            textField.centerYAnchor.constraint(equalTo: cell.centerYAnchor),
        ])

        return cell
    }

    func tableViewSelectionDidChange(_ notification: Notification) {
        guard !isUpdatingDetailFields else { return }

        let row = tableView.selectedRow
        selectedIndex = row >= 0 ? row : nil
        updateDetailFields()
    }
}

extension ConfigureWindowController: NSTextViewDelegate {

    func textDidChange(_ notification: Notification) {
        guard notification.object as? NSTextView === stepsTextView else { return }
        commitDetailFieldsToSelection()
    }
}
