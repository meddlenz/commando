//
//  UserDefaultsExtension.swift
//  Command Runner
//

import Foundation

private let serverCommandsKey = "serverCommandsV2"
private let legacyServerCommandsKey = "serverCommands"

extension UserDefaults {

    var serverCommands: [ServerCommand] {
        get {
            if let data = data(forKey: serverCommandsKey),
               let commands = try? JSONDecoder().decode([ServerCommand].self, from: data) {
                return commands
            }

            return migrateLegacyCommands()
        }
        set {
            guard let data = try? JSONEncoder().encode(newValue) else { return }
            set(data, forKey: serverCommandsKey)
            NotificationCenter.default.post(name: .serverCommandsDidChange, object: nil)
        }
    }

    private func migrateLegacyCommands() -> [ServerCommand] {
        guard let data = data(forKey: legacyServerCommandsKey) else { return [] }

        if let commands = try? JSONDecoder().decode([ServerCommand].self, from: data) {
            self.serverCommands = commands
            return commands
        }

        guard let legacyCommands = try? NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(data) as? [ServerCommand] else {
            return []
        }

        let migrated = legacyCommands.map { command in
            ServerCommand(
                name: command.name.isEmpty ? command.serverDetails : command.name,
                serverDetails: command.serverDetails,
                steps: command.nonEmptySteps.isEmpty ? [""] : command.nonEmptySteps
            )
        }

        if !migrated.isEmpty {
            serverCommands = migrated
        }

        return migrated
    }
}
