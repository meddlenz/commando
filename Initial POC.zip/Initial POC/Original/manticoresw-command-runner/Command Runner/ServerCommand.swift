//
//  ServerCommand.swift
//  Command Runner
//

import Foundation

extension Notification.Name {
    static let serverCommandsDidChange = Notification.Name("serverCommandsDidChange")
}

class ServerCommand: NSObject, Codable, NSCopying {
    var name: String
    var serverDetails: String
    var steps: [String]

    init(name: String = "New Command", serverDetails: String = "username@host", steps: [String] = [""]) {
        self.name = name
        self.serverDetails = serverDetails
        self.steps = steps.isEmpty ? [""] : steps
    }

    enum CodingKeys: String, CodingKey {
        case name
        case serverDetails
        case steps
        case command
    }

    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        name = try container.decodeIfPresent(String.self, forKey: .name) ?? "New Command"
        serverDetails = try container.decodeIfPresent(String.self, forKey: .serverDetails) ?? "username@host"

        if let decodedSteps = try container.decodeIfPresent([String].self, forKey: .steps), !decodedSteps.isEmpty {
            steps = decodedSteps
        } else if let legacyCommand = try container.decodeIfPresent(String.self, forKey: .command), !legacyCommand.isEmpty {
            steps = [legacyCommand]
        } else {
            steps = [""]
        }
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(name, forKey: .name)
        try container.encode(serverDetails, forKey: .serverDetails)
        try container.encode(steps, forKey: .steps)
    }

    func copy(with zone: NSZone? = nil) -> Any {
        ServerCommand(name: name, serverDetails: serverDetails, steps: steps)
    }

    var nonEmptySteps: [String] {
        steps
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
    }

    var stepsSummary: String {
        let commands = nonEmptySteps
        guard !commands.isEmpty else { return "No steps" }
        if commands.count == 1 { return commands[0] }
        return "\(commands.count) steps"
    }
}

struct SSHConnection {
    let username: String
    let host: String
    let port: Int?

    static func parse(from serverDetails: String) -> SSHConnection? {
        let trimmed = serverDetails.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }

        let hostPart: String
        let username: String

        if let atIndex = trimmed.lastIndex(of: "@") {
            username = String(trimmed[..<atIndex])
            hostPart = String(trimmed[trimmed.index(after: atIndex)...])
        } else {
            return nil
        }

        guard !username.isEmpty, !hostPart.isEmpty else { return nil }

        if let colonIndex = hostPart.lastIndex(of: ":"),
           hostPart[hostPart.index(after: colonIndex)...].allSatisfy(\.isNumber) {
            let host = String(hostPart[..<colonIndex])
            let portString = String(hostPart[hostPart.index(after: colonIndex)...])
            guard let port = Int(portString), !host.isEmpty else { return nil }
            return SSHConnection(username: username, host: host, port: port)
        }

        return SSHConnection(username: username, host: hostPart, port: nil)
    }
}
