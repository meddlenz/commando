//
//  CommandExecutor.swift
//  Command Runner
//

import Foundation

enum CommandExecutor {

    enum ExecutionError: LocalizedError {
        case invalidServerDetails
        case noSteps
        case terminalLaunchFailed(String)

        var errorDescription: String? {
            switch self {
            case .invalidServerDetails:
                return "Server details must be in the format username@host or username@host:port."
            case .noSteps:
                return "This command has no steps to run."
            case .terminalLaunchFailed(let message):
                return "Failed to open Terminal: \(message)"
            }
        }
    }

    static func run(_ command: ServerCommand) throws {
        guard let connection = SSHConnection.parse(from: command.serverDetails) else {
            throw ExecutionError.invalidServerDetails
        }

        let steps = command.nonEmptySteps
        guard !steps.isEmpty else {
            throw ExecutionError.noSteps
        }

        let remoteScript = steps
            .map { "(\($0))" }
            .joined(separator: " && ")

        var sshInvocation = "ssh"
        if let port = connection.port {
            sshInvocation += " -p \(port)"
        }
        sshInvocation += " \(shellQuote("\(connection.username)@\(connection.host)")) \(shellQuote(remoteScript))"

        try openInTerminal(command: sshInvocation)
    }

    private static func openInTerminal(command: String) throws {
        let escapedCommand = command
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "\"", with: "\\\"")

        let script = """
        tell application "Terminal"
            activate
            do script "\(escapedCommand)"
        end tell
        """

        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/bin/osascript")
        process.arguments = ["-e", script]

        let errorPipe = Pipe()
        process.standardError = errorPipe

        try process.run()
        process.waitUntilExit()

        guard process.terminationStatus == 0 else {
            let errorData = errorPipe.fileHandleForReading.readDataToEndOfFile()
            let message = String(data: errorData, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines)
            throw ExecutionError.terminalLaunchFailed(message ?? "Unknown error")
        }
    }

    private static func shellQuote(_ value: String) -> String {
        "'" + value.replacingOccurrences(of: "'", with: "'\\''") + "'"
    }
}
